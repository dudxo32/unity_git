﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace WindowsFormsApp2
{
   
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            byte[] rByte = new byte[16];
            Stream stuFile = new FileStream("student.dat", FileMode.OpenOrCreate);
            BinaryFormatter deserializer = new BinaryFormatter();
            student stu = (student)deserializer.Deserialize(stuFile);

            stu_name.Text = stu.name;
            stu_num.Text = stu.num;
            stu_gender.Text = stu.gender;

            stuFile.Close();




        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            Stream ws = new FileStream("student.dat", FileMode.OpenOrCreate);
            BinaryFormatter serializer = new BinaryFormatter();

            student stu = new student();
            stu.name = stu_name.Text;
            stu.num = stu_num.Text;
            stu.gender = stu_gender.Text;

            serializer.Serialize(ws,stu);
            ws.Close();

            
        }
    }
    [Serializable]
    class student
    {
        public string name;
        public string num;
        public string gender;
    }
}
